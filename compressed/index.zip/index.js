exports.handler = (event, context) => {
  context.succeed("Hello Lambda World!");
};

// Fuller, Matthew. AWS Lambda: A Guide to Serverless Microservices (Kindle Locations 168-169). UNKNOWN. Kindle Edition. 